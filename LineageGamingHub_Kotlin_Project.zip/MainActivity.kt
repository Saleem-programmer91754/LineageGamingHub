package com.lineage.gaminghub

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

data class Game(val name: String, var playTimeMillis: Long = 0L)

class MainActivity : ComponentActivity() {

    private lateinit var prefs: SharedPreferences
    private var currentGameStartTime = 0L
    private var currentGameName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("gaming_hub_prefs", Context.MODE_PRIVATE)

        setContent {
            var games by remember { mutableStateOf(loadGames()) }
            var boosting by remember { mutableStateOf(false) }
            var doNotDisturb by remember { mutableStateOf(false) }
            var activeGame by remember { mutableStateOf<Game?>(null) }

            fun startGame(game: Game) {
                stopCurrentGame()

                currentGameName = game.name
                currentGameStartTime = SystemClock.elapsedRealtime()
                activeGame = game
            }

            fun stopCurrentGame() {
                val now = SystemClock.elapsedRealtime()
                currentGameName?.let { name ->
                    val playedMillis = now - currentGameStartTime
                    val idx = games.indexOfFirst { it.name == name }
                    if (idx >= 0) {
                        val updatedGame = games[idx].copy(playTimeMillis = games[idx].playTimeMillis + playedMillis)
                        games = games.toMutableList().also { it[idx] = updatedGame }
                        saveGamePlayTime(updatedGame)
                    }
                }
                currentGameName = null
                currentGameStartTime = 0L
                activeGame = null
            }

            LaunchedEffect(activeGame) {
                while (activeGame != null) {
                    delay(1000L)
                    games = games.toList()
                }
            }

            fun saveGamePlayTime(game: Game) {
                prefs.edit().putLong("playtime_${game.name}", game.playTimeMillis).apply()
            }

            fun loadGames(): List<Game> {
                val gameNames = listOf("PUBG Mobile", "Call of Duty", "Asphalt 9", "Genshin Impact")
                return gameNames.map {
                    Game(it, prefs.getLong("playtime_$it", 0L))
                }
            }

            MaterialTheme {
                Scaffold(
                    topBar = {
                        CenterAlignedTopAppBar(title = { Text("Lineage Gaming Hub") })
                    }
                ) { padding ->
                    Column(
                        modifier = Modifier
                            .padding(padding)
                            .fillMaxSize()
                            .background(Color(0xFF121212))
                            .padding(16.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Button(
                                onClick = {
                                    boosting = true
                                    LaunchedEffect(Unit) {
                                        kotlinx.coroutines.delay(1500)
                                        boosting = false
                                    }
                                },
                                enabled = !boosting,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (boosting) "Boosting..." else "Boost")
                            }

                            Button(
                                onClick = {
                                    doNotDisturb = !doNotDisturb
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (doNotDisturb) "DND On" else "DND Off")
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                        Text("Your Games", color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(12.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(games) { game ->
                                GameCard(
                                    game = game,
                                    isActive = activeGame?.name == game.name,
                                    onClick = { startGame(game) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun GameCard(game: Game, isActive: Boolean, onClick: () -> Unit) {
        Card(
            modifier = Modifier
                .width(160.dp)
                .clickable(onClick = onClick),
            colors = CardDefaults.cardColors(
                containerColor = if (isActive) Color(0xFF1E88E5) else Color(0xFF222222)
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(game.name, color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = formatMillisToTime(game.playTimeMillis),
                    color = Color.LightGray
                )
            }
        }
    }

    fun formatMillisToTime(millis: Long): String {
        val totalSeconds = millis / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    override fun onPause() {
        super.onPause()
        currentGameName?.let {
            val now = SystemClock.elapsedRealtime()
            val playedMillis = now - currentGameStartTime
            val prevTime = prefs.getLong("playtime_$it", 0L)
            prefs.edit().putLong("playtime_$it", prevTime + playedMillis).apply()
            currentGameName = null
            currentGameStartTime = 0L
        }
    }
}